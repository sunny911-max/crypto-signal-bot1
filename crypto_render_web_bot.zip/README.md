# Crypto Render Web Bot
A Flask-based 24/7 crypto signal bot running for free on Render Web Service.